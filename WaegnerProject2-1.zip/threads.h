#include "q.h"

struct TCB_t *RunQ;

void start_thread(void *function, int arg1, int arg2) {
    struct TCB_t *dummy = (struct TCB_t*) malloc(sizeof(struct TCB_t));
    void *stack = malloc(8192);
    init_TCB(dummy, function, stack, 8192, arg1, arg2);
    AddQueue(&RunQ, dummy);
}

void run() {
    ucontext_t parent;
    getcontext(&parent);
    swapcontext(&parent, &(RunQ->context));
}

void yield() {
    RotateQ(&RunQ);
    swapcontext(&(RunQ->prev->context), &RunQ->context);
}