#include "threads.h"

typedef struct semaphore {
    int value;
    struct TCB_t* list;
} semaphore;

void InitSem(struct semaphore* sem, int i) {
    sem->value = i;
    InitQueue(&sem->list);
}

void P(struct semaphore* sem, int tID) {
    while(1) {
        if (sem->value <= 0) {
            struct TCB_t *temp1 = DelQueue(&RunQ);
            AddQueue(&(sem->list), temp1); /*
            if (tID > 0) {
                printf("\n Producer %d is waiting \n", tID);
            } else {
                printf("\n Consumer %d is waiting \n", tID * -1);
            } */

            struct TCB_t *temp2 = sem->list;
            while(temp2->next != sem->list) {
                temp2 = temp2->next;
            }

            if (RunQ == NULL) {
                return;
            } else {
                swapcontext(&(temp2->context), &(RunQ->context));
            }

        } else {
            sem->value--;
            return;
        }
    }
}

void V(struct semaphore* sem) {
    struct TCB_t *temp;
    if (sem->list != NULL) {
        temp = DelQueue(&sem->list);
        AddQueue(&RunQ, temp);
    }
    sem->value++;
}