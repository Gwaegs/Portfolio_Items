#include "tcb.h"
#include <stdio.h>
#include <stdlib.h>

struct item{
    int num;
    struct item* next;
    struct item* prev;
} item;

struct TCB_t* NewItem();    			//creates a item and gives it a number
void InitQueue(struct TCB_t **head); 			//creates a NULL head pointer
void AddQueue(struct TCB_t** head, struct TCB_t* new_Item);
struct TCB_t* DelQueue(struct TCB_t** head);
void RotateQ(struct TCB_t** head);

struct TCB_t* NewItem() {
    struct TCB_t *t = (struct TCB_t*) malloc(sizeof(struct TCB_t));
    t->next = NULL;
    t->prev = NULL;
    return t;
}

void InitQueue(struct TCB_t **head) {
    *head = NULL;
}

void AddQueue(struct TCB_t** head, struct TCB_t* new_Item) {
    if ((*head) == NULL){  //initialize head (no items)
        (*head) = new_Item;
        (*head)->next = *head;
        (*head)->prev = *head;
        //(*head)->num = new_Item->num;
    }
    else {
        if ((*head)->next == *head) {      // only head in the queue
            (*head)->next = new_Item;
            (*head)->prev = new_Item;
            new_Item->next = *head;
            new_Item->prev = *head;
        } else {
            (*head)->prev->next = new_Item;
            new_Item->prev = (*head)->prev;
            (*head)->prev = new_Item;
            new_Item->next = *head;
        }
    }
}

struct TCB_t* DelQueue(struct TCB_t** head) {
    struct TCB_t* deleted = *head;

    if (*head == NULL) {
        printf("Nothing to Delete!\n");
    } else {
        if ((*head)->next == *head) {
            *head = NULL;
        } else {
            (*head)->next->prev = (*head)->prev;
            (*head)->prev->next = (*head)->next;
            *head = (*head)->next;
        }
    }

    return deleted;
}

void RotateQ(struct TCB_t** head) {
    AddQueue(head, DelQueue(head));
}